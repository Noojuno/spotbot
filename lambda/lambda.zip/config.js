const config = {
  spotify: {
    client_id: "2741091806ce4f9d8236ed7fb1572696",
    client_secret: "355b2b5d7e514367af6c8a3379a42ff4",
    user_name: "t70698cg9lkwh4b85syn0v4us",
    redirect_uri: "http://a.local",
    code:
      "AQBPBealoJdI6Ap0bc-BT-jHI-ZytBXMq6_fS9whh0PvuBNTQQPGUg6QICPjYxI5yPfTR8GHAUsZR0BB8NPbGJW0sTf88kMS-aL--CtjgUzFTOKiowmyCKVJRr63hKVDNzHbq6t1qf7v4btT9Mf-WeU5cDHDA9crnXnXf5ORZiCCruG_EDR6LRvord6V5ltgAoM50BXEOkolHA4_ErSAJwRNEouUNkA4VcAXk3zq0uWGOPfingIYdo5v3QBgvbm3nPf3ghYxYqm4iqB3BmF5LFgltWw70H9EtJRumEm-_vSSDm7SpzYyJmUZukvYTdRSwYm-Tw",
    tokens: {
      access_token:
        "BQCKBDT56c9ktS7K2n_h7Vt7UUQ5s1nr1Wmu8utdE1y9RZTxgII5SVvMg-m2KMQMYRJIrc0ZXmNP7raKHOSFGsnAbHM41_WRd-MMSUTe0NeQIaPfR6fSv_ON9uZM2R-CiVH4r8NThVh84VrKvHcyCpde-L-iebxTnItIanMGJDIAzRWf8LmaO5Lm8vlT53gPN0czrwprfp7GLYJ-KVGI3O3Zwgiix__hBIIrH7jOALS7Uj0wT7DX",
      refresh_token:
        "AQBuVX9xcpibkqdzs5D-D1qS1LwH4uZsxhe8wbGI4MESdWp1iXlybUsSldow7lQlqe66a2craobstlm9F-ykR3fM_d4U8wWkmCrmjyBHZn7Vkj4vkHkcfbmI5oyCnCuW3lQ",
      scope:
        "playlist-read-private user-library-read user-library-modify playlist-modify-private playlist-modify-public"
    }
  }
};
module.exports = config;
