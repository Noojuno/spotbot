# SpotBot

A super cool Spotify bot! 
